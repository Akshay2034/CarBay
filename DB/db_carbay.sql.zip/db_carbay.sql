-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 08, 2021 at 10:26 AM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db_carbay`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `admin_id` int(11) NOT NULL auto_increment,
  `admin_username` varchar(50) NOT NULL,
  `admin_password` varchar(50) NOT NULL,
  PRIMARY KEY  (`admin_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`admin_id`, `admin_username`, `admin_password`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bookservice`
--

CREATE TABLE `tbl_bookservice` (
  `booking_id` int(11) NOT NULL auto_increment,
  `user_id` int(11) NOT NULL,
  `payment_status` int(11) NOT NULL,
  `workshopservice_id` int(11) NOT NULL,
  `landmark` varchar(50) NOT NULL,
  `booking_date&time` date NOT NULL,
  PRIMARY KEY  (`booking_id`,`workshopservice_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tbl_bookservice`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_complaint`
--

CREATE TABLE `tbl_complaint` (
  `complaint_id` int(11) NOT NULL auto_increment,
  `complaint_title` varchar(50) NOT NULL,
  `complaint_content` varchar(50) NOT NULL,
  `complaint_date` date NOT NULL,
  `complaint_status` varchar(50) NOT NULL,
  `complaint_reply` varchar(50) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY  (`complaint_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tbl_complaint`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_complainttype`
--

CREATE TABLE `tbl_complainttype` (
  `complainttype_id` int(11) NOT NULL auto_increment,
  `complainttype_name` varchar(50) NOT NULL,
  PRIMARY KEY  (`complainttype_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `tbl_complainttype`
--

INSERT INTO `tbl_complainttype` (`complainttype_id`, `complainttype_name`) VALUES
(9, 'Delay in Response');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_district`
--

CREATE TABLE `tbl_district` (
  `district_id` int(11) NOT NULL auto_increment,
  `district_name` varchar(50) NOT NULL,
  PRIMARY KEY  (`district_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `tbl_district`
--

INSERT INTO `tbl_district` (`district_id`, `district_name`) VALUES
(6, 'Thiruvananthapuram'),
(7, 'Kollam'),
(8, 'pathanamthitta'),
(9, 'Alapuzha'),
(10, 'Kottayam'),
(11, 'Idukki'),
(12, 'Ernakulam'),
(13, 'Thrisssur'),
(15, 'Palakad'),
(16, 'Malapuram'),
(17, 'Kozhikode'),
(18, 'Wayanad'),
(19, 'Kannur'),
(20, 'Kasaragod');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_feedback`
--

CREATE TABLE `tbl_feedback` (
  `feedback_id` int(11) NOT NULL auto_increment,
  `feedback_date` date NOT NULL,
  `feedback` varchar(50) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY  (`feedback_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tbl_feedback`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_model`
--

CREATE TABLE `tbl_model` (
  `model_id` int(11) NOT NULL auto_increment,
  `model_name` varchar(50) NOT NULL,
  PRIMARY KEY  (`model_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `tbl_model`
--

INSERT INTO `tbl_model` (`model_id`, `model_name`) VALUES
(2, 'BMW'),
(3, 'MARUTHI');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_place`
--

CREATE TABLE `tbl_place` (
  `place_id` int(11) NOT NULL auto_increment,
  `place_name` varchar(50) NOT NULL,
  `district_id` int(50) NOT NULL,
  PRIMARY KEY  (`place_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=32 ;

--
-- Dumping data for table `tbl_place`
--

INSERT INTO `tbl_place` (`place_id`, `place_name`, `district_id`) VALUES
(16, 'Kottarakara', 6),
(17, 'Kottamkara', 7),
(18, 'Konni', 8),
(19, 'Kuttanad', 9),
(20, 'Ettumanoor', 10),
(21, 'Adimali', 11),
(22, 'Piravom', 12),
(23, 'Guruvayur', 13),
(24, 'Alathur', 15),
(25, 'Nilamboor', 16),
(26, 'Thamarassery', 17),
(28, 'Pulpally', 18),
(30, 'Iritty', 19),
(31, 'Bekal', 20);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_productbooking`
--

CREATE TABLE `tbl_productbooking` (
  `booking_id` int(11) NOT NULL auto_increment,
  `booking_date&time` date NOT NULL,
  `booking_qty` int(11) NOT NULL,
  `product_id` varchar(50) NOT NULL,
  `user_id` int(11) NOT NULL,
  `payment_status` varchar(50) NOT NULL,
  `booking_amount` int(11) NOT NULL,
  PRIMARY KEY  (`booking_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tbl_productbooking`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_productrating`
--

CREATE TABLE `tbl_productrating` (
  `rating_id` int(11) NOT NULL auto_increment,
  `productbooking_id` int(11) NOT NULL,
  `rating_count` varchar(50) NOT NULL,
  `rating_caption` varchar(100) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY  (`rating_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tbl_productrating`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_shoprating`
--

CREATE TABLE `tbl_shoprating` (
  `rating_id` int(11) NOT NULL auto_increment,
  `shopbooking_id` int(11) NOT NULL,
  `rating_count` varchar(50) NOT NULL,
  `rating_caption` varchar(50) NOT NULL,
  `user_i8d` int(11) NOT NULL,
  PRIMARY KEY  (`rating_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tbl_shoprating`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_sparecat`
--

CREATE TABLE `tbl_sparecat` (
  `sparecat_id` int(11) NOT NULL auto_increment,
  `sparecat_name` varchar(50) NOT NULL,
  PRIMARY KEY  (`sparecat_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `tbl_sparecat`
--

INSERT INTO `tbl_sparecat` (`sparecat_id`, `sparecat_name`) VALUES
(2, 'Engine'),
(3, 'Tyre'),
(4, 'Brakes');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sparesubcat`
--

CREATE TABLE `tbl_sparesubcat` (
  `sparesubcat_id` int(11) NOT NULL auto_increment,
  `sparesubcat_name` varchar(50) NOT NULL,
  `sparecat_id` int(11) NOT NULL,
  PRIMARY KEY  (`sparesubcat_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `tbl_sparesubcat`
--

INSERT INTO `tbl_sparesubcat` (`sparesubcat_id`, `sparesubcat_name`, `sparecat_id`) VALUES
(3, 'Front Tyre', 3),
(4, 'Bike Engine', 2),
(6, 'Disc brakes', 4);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_stock`
--

CREATE TABLE `tbl_stock` (
  `stock_id` int(11) NOT NULL auto_increment,
  `stock_date` date NOT NULL,
  `stock_qty` varchar(50) NOT NULL,
  `product_id` varchar(50) NOT NULL,
  PRIMARY KEY  (`stock_id`,`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tbl_stock`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `user_id` int(11) NOT NULL auto_increment,
  `user_name` varchar(50) NOT NULL,
  `user_contact` int(11) NOT NULL,
  `user_email` varchar(50) NOT NULL,
  `user_address` varchar(50) NOT NULL,
  `place_id` int(11) NOT NULL,
  `user_password` varchar(50) NOT NULL,
  `user_doj` date NOT NULL,
  `user_photo` varchar(50) NOT NULL,
  `user_proof` varchar(50) NOT NULL,
  `user_isactive` varchar(50) NOT NULL,
  PRIMARY KEY  (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`user_id`, `user_name`, `user_contact`, `user_email`, `user_address`, `place_id`, `user_password`, `user_doj`, `user_photo`, `user_proof`, `user_isactive`) VALUES
(3, 'Karthik babu', 2147483647, 'karthikbabu3026@gmail.com', 'Thachethukandathil(H) pazhoor east piravom p.o', 22, 'karthik', '2021-10-05', '', '', '0'),
(4, 'Keerthi babu', 2147483647, 'keerthikbabu3026@gmail.com', 'Thachethukandathil(H) pazhoor east piravom p.o', 16, 'keerthi', '2021-10-08', '', '', '0');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_workshop`
--

CREATE TABLE `tbl_workshop` (
  `workshop_id` int(11) NOT NULL auto_increment,
  `workshop_name` varchar(50) NOT NULL,
  `workshop_contact` int(11) NOT NULL,
  `workshop_email` varchar(50) NOT NULL,
  `workshop_address` varchar(50) NOT NULL,
  `place_id` varchar(50) NOT NULL,
  `workshop_status` varchar(50) NOT NULL,
  `workshop_password` varchar(50) NOT NULL,
  `workshop_proof` varchar(50) NOT NULL,
  `workshop_photo` varchar(50) NOT NULL,
  `workshop_doj` date NOT NULL,
  PRIMARY KEY  (`workshop_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `tbl_workshop`
--

INSERT INTO `tbl_workshop` (`workshop_id`, `workshop_name`, `workshop_contact`, `workshop_email`, `workshop_address`, `place_id`, `workshop_status`, `workshop_password`, `workshop_proof`, `workshop_photo`, `workshop_doj`) VALUES
(3, 'rodo tyres', 2147483647, 'rod3026@gmail.com', 'near piravom busstand', '22', '1', 'rodo', 'vidyaSIGN.jpg', 'vidya.jpg', '2021-10-05');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_workshopproduct`
--

CREATE TABLE `tbl_workshopproduct` (
  `product_id` int(11) NOT NULL auto_increment,
  `product_details` varchar(50) NOT NULL,
  `sparesubcat_id` int(11) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `product_rate` int(11) NOT NULL,
  `product_photo` varchar(100) NOT NULL,
  `workshop_id` int(11) NOT NULL,
  PRIMARY KEY  (`product_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `tbl_workshopproduct`
--

INSERT INTO `tbl_workshopproduct` (`product_id`, `product_details`, `sparesubcat_id`, `product_name`, `product_rate`, `product_photo`, `workshop_id`) VALUES
(1, 'goog stability and duarability', 3, 'CEAT TYRES', 3050, 'ceat-png', 3),
(3, 'advanced power brakng system', 6, 'Yamaha.', 4000, 'disc brake', 3);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_workshopservice`
--

CREATE TABLE `tbl_workshopservice` (
  `workshopservice_id` int(11) NOT NULL auto_increment,
  `workshop_id` int(11) NOT NULL,
  `workshopservice_title` varchar(50) NOT NULL,
  `workshopservice_description` varchar(50) NOT NULL,
  `service_amount` varchar(50) NOT NULL,
  PRIMARY KEY  (`workshopservice_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `tbl_workshopservice`
--

